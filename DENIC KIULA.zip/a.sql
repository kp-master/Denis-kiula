CREATE DATABASE contact_db;

CREATE TABLE contacts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  firstName VARCHAR(100) NOT NULL,
  lastName VARCHAR(100) NOT NULL,
  gender VARCHAR(50),
  food VARCHAR(50),
  education VARCHAR(50),
  time VARCHAR(50),
  quote TEXT
);
