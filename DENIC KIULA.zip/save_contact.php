<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['first-name'];
    $lastName = $_POST['last-name'];
    $gender = $_POST['gender'];
    $food = $_POST['favorite-food'];
    $education = $_POST['education-level'];
    $time = $_POST['favorite-time'];
    $quote = $_POST['favorite-quote'];

    $sql = "INSERT INTO contacts (firstName, lastName, gender, food, education, time, quote)
            VALUES ('$firstName', '$lastName', '$gender', '$food', '$education', '$time', '$quote')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['message' => 'Contact saved successfully!']);
    } else {
        echo json_encode(['error' => 'Error: ' . $conn->error]);
    }
    $conn->close();
}
?>
