<?php
$servername = "localhost";
$username = "root";  // Change this according to your MySQL username
$password = "";  // Change this according to your MySQL password
$dbname = "contact_db";  // The database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
